require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.activity.EdgeToEdge"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatTextView"
import "com.google.android.material.button.MaterialButton"
-- 内置控件(随 IDE 发布,非三方库):短名可直接写进布局表
import "com.luaforge.studio.widget.glass.LiquidGlassView"

EdgeToEdge.enable(activity)

activity
.setTheme(R.style.Theme_Material3_Blue_NoActionBar)
.setTitle("AppName")
.setContentView(loadlayout("layout"))

-- id 写完即成全局变量,可直接引用控件
local colors = { 0x40FFFFFF, 0x554A8CFF, 0x55FF5A8A, 0x6600E0A0 }
local index = 1

toggle.onClick = function()
  index = index % #colors + 1
  glass.setGlassColor(colors[index])
  hint.setText(string.format("玻璃底色已切换为 0x%08X", colors[index]))
end
