-- Jetpack Compose 示例(方案 A:Lua 描述 UI 树 -> Kotlin 桥渲染)
-- 说明:Lua 无法直接调用 @Composable,统一用 table 描述组件树:
--   [1] 为标签,位置文本给 Text/Button,其余 table 为子节点,其它键为属性。

require "import"
import "android.widget.*"
import "androidx.activity.EdgeToEdge"

EdgeToEdge.enable(activity)

activity.setTitle("Compose 示例")

composeContent({
  "Column",
  fillMaxWidth = true,
  padding = 20,
  spacing = 14,
  {
    "Text", "Jetpack Compose 示例",
    size = 26, bold = true, align = "center", fillMaxWidth = true,
  },
  {
    "Text", "由 Lua 描述界面,由 Kotlin 渲染为 Material3 组件",
    size = 14, align = "center", fillMaxWidth = true,
  },
  { "Spacer", h = 6 },
  {
    "Card", corner = 18, fillMaxWidth = true,
    {
      "Column", spacing = 10,
      { "Text", "这是一个圆角卡片", size = 16, bold = true },
      { "Text", "支持 Column / Row / Box / Card / Text / Button / Spacer / Divider" },
    },
  },
  {
    "Row", spacing = 12,
    {
      "Button", "点我",
      onClick = function()
        Toast.makeText(activity, "按钮被点击了", Toast.LENGTH_SHORT).show()
      end,
    },
    {
      "Button", "退出",
      onClick = function()
        activity.finish()
      end,
    },
  },
  { "Divider" },
  {
    "Text", "提示:颜色用 0xAARRGGBB 数字,如 color = 0xFF6650a4",
    size = 12, color = 0xFF6650a4,
  },
})
