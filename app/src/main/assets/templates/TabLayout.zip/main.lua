require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.activity.EdgeToEdge"
import "androidx.coordinatorlayout.widget.CoordinatorLayout"
import "androidx.viewpager2.widget.ViewPager2"
import "com.google.android.material.tabs.TabLayoutMediator"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatTextView"
import "com.google.android.material.appbar.AppBarLayout"
import "com.google.android.material.tabs.TabLayout"
import "com.google.android.material.appbar.MaterialToolbar"

EdgeToEdge.enable(activity)

activity
.setTheme(R.style.Theme_Material3_Blue_NoActionBar)
.setTitle("AppName")
.setContentView(loadlayout("layout"))
.setSupportActionBar(toolbar)
.getSupportActionBar()

-- ViewPager2 无 setupWithViewPager,改用 TabLayoutMediator 绑定页签与标题
local titles = { "Tab1", "Tab2", "Tab3" }

local mediator = TabLayoutMediator(mTab, cvpg, TabLayoutMediator.TabConfigurationStrategy{
  onConfigureTab = function(tab, position)
    tab.setText(titles[position + 1])
  end
})
mediator.attach()